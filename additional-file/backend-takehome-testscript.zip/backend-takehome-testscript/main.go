package main

import (
	"bytes"
	"fmt"
	"io"
	"net/http"
)

type Endpoint struct {
	Name    string
	Method  string
	URL     string
	Body    string
	Headers map[string]string
}

var token string = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiOGVhYmU0OGUtZjNhMS00NjgyLTg3ODMtOTdjMjJjYTk1MjgwIiwidXNlcm5hbWUiOiJ0eXJpb24iLCJleHAiOjE3MjUwNzYxMTJ9.qAVqrFjvNAnwZ3DuUbV1w01KI24UaKAK43xcelDG9gg"
var userID string = "8eabe48e-f3a1-4682-8783-97c22ca95280"

func main() {
	endpoints := []Endpoint{
		// {
		// 	Name:   "Register",
		// 	Method: "POST",
		// 	URL:    "http://localhost:8080/user/register",
		// 	Body: `{
		// 		"username": "tyrion",
		// 		"email": "lannister@mail.com",
		// 		"password": "testpassword"
		// 	}`,
		// 	Headers: map[string]string{"Content-Type": "application/json"},
		// },
		// {
		// 	Name:   "Login",
		// 	Method: "POST",
		// 	URL:    "http://localhost:8080/user/login",
		// 	Body: `{
		// 		"username": "tyrion",
		// 		"password": "testpassword"
		// 	}`,
		// 	Headers: map[string]string{"Content-Type": "application/json"},
		// },
		// {
		// 	Name:   "[Dummy] Check Token",
		// 	Method: "POST",
		// 	URL:    "http://localhost:8080/user/token",
		// 	Body: `{
		// 		"username": "tyrion",
		// 		"password": "testpassword"
		// 	}`,
		// 	Headers: map[string]string{
		// 		"Content-Type":  "application/json",
		// 		"Authorization": token,
		// 	},
		// },
		{
			Name:   "Create Post",
			Method: "POST",
			URL:    "http://localhost:8080/posts",
			Body: `{
				"title": "test post 1",
				"content": "test content 1"
			}`,
			Headers: map[string]string{
				"Content-Type":  "application/json",
				"Authorization": token,
			},
		},
		{
			Name:   "Get Post By ID",
			Method: "GET",
			URL:    "http://localhost:8080/posts/1",
			Headers: map[string]string{
				"Authorization": token,
			},
		},
		{
			Name:   "Get All Post",
			Method: "GET",
			URL:    "http://localhost:8080/posts",
			Headers: map[string]string{
				"Authorization": token,
			},
		},
		{
			Name:   "Get Post By Author ID",
			Method: "GET",
			URL:    "http://localhost:8080/posts/author/" + userID,
			Headers: map[string]string{
				"Authorization": token,
			},
		},
		{
			Name:   "Update Post By ID",
			Method: "PUT",
			URL:    "http://localhost:8080/posts/1",
			Body: `{
				"title": "test update title",
				"content": "test update content"
			}`,
			Headers: map[string]string{
				"Content-Type":  "application/json",
				"Authorization": token,
			},
		},
		{
			Name:   "Create Comment",
			Method: "POST",
			URL:    "http://localhost:8080/posts/1/comment",
			Headers: map[string]string{
				"Authorization": token,
			},
			Body: `{
				"post_id": 1,
				"content": "test comment 1"
			}`,
		},
		{
			Name:   "Get Comment By Post ID",
			Method: "GET",
			URL:    "http://localhost:8080/posts/1/comment",
			Headers: map[string]string{
				"Authorization": token,
			},
		},
		// put this delete on last
		{
			Name:   "Delete Post By ID",
			Method: "DELETE",
			URL:    "http://localhost:8080/posts/1",
			Headers: map[string]string{
				"Authorization": token,
			},
		},
	}

	var successCount int

	for _, endpoint := range endpoints {
		req, err := http.NewRequest(endpoint.Method, endpoint.URL, bytes.NewBufferString(endpoint.Body))
		if err != nil {
			fmt.Printf("Error creating request for %s: %v\n", endpoint.Name, err)
			continue
		}

		for key, value := range endpoint.Headers {
			req.Header.Set(key, value)
		}

		client := &http.Client{}
		resp, err := client.Do(req)
		if err != nil {
			fmt.Printf("Error making request for %s: %v\n", endpoint.Name, err)
			continue
		}
		defer resp.Body.Close()

		body, _ := io.ReadAll(resp.Body)

		if resp.StatusCode == http.StatusOK || resp.StatusCode == http.StatusCreated {
			fmt.Printf("Test %s passed with status code: %d\n", endpoint.Name, resp.StatusCode)
			successCount++
		} else {
			fmt.Printf("Test %s failed with status code: %d, response: %s\n", endpoint.Name, resp.StatusCode, string(body))
		}
	}

	totalTests := len(endpoints)
	passPercentage := (float64(successCount) / float64(totalTests)) * 100

	fmt.Printf("\nTotal Tests: %d\n", totalTests)
	fmt.Printf("Passed Tests: %d\n", successCount)
	fmt.Printf("Passing Percentage: %.2f%%\n", passPercentage)
}
