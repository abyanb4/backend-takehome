# Endpoint Test Script
Because I don't have time to create unit test, I figure to just create end-to-end script here

> ⚠️ **IMPORTANT:** Anw it can only be run 1 time since I harcode the postID

## How To Use
1. Register and Login manually using the postman collection provided
2. Save the `token` from login, and `userID` from register
3. Place it on the `token` and `userID` variable in `main.go`
4. Voila, just run `go run main.go` and see the percentage